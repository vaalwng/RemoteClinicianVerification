export default colors = {
    
    white: "#ffffff",
    button: { 
        primary: "#34b1eb", 
        secondary: "#ACBAC3" 
    },
    text: {
        darkGray: "#57636F",
        lightGray: "#7A8D9C"
    },
    background: '#F6F6F7',
   
}