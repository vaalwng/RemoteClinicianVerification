const mainColor = 'gray'

export default mainColor
